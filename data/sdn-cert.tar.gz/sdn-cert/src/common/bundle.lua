require "common/class"
require "common/exception"