---
-- dummy module to require all files in folder
-- @script tools.bundle

require "tools/csv"
require "tools/float"
require "tools/tables"
require "tools/strings"
require "tools/files"
require "tools/histogram"
require "tools/statistic"
require "tools/random_variable"
require "tools/normal_distribution"
require "tools/general"
