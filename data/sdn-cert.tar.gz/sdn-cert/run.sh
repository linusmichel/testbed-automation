#!/bin/bash

./src/main.lua $@
