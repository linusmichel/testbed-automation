Timestamping Tests
==================

Use test-timestamping-capabilities.lua to test the timestamping capabilities of your hardware.
This script works best with two directly connected ports.
