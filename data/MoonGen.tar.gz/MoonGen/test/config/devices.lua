-- Just start MoonGen.

local dpdk	= require "dpdk"

function master()
	slave()
end

-- Do nothing.
function slave()
end
