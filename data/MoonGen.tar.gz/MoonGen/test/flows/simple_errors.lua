Flow()
Flow{{}}
Flow{""}
Flow("abc")
Flow{" ab"}
Flow{";ab"}
Flow{":ab"}
Flow{",ab"}

Packet()
Packet{}
Packet.abc()
Packet.abc("abc")
Packet.abc = "abc"
Packet[{}]("abc")
Packet[{}]{}

ip(12)
ip{}
ip""
ip"abc"
ip"10.1..."
mac(12)
mac{}
mac""
mac"abc"
mac"10:::::"
