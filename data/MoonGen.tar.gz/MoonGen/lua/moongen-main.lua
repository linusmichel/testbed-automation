
-- compatibility stuff for deprecated functions
require "moongen-compat"

-- load moongen-specific modules
require "software-timestamps"
require "crc-ratecontrol"
require "software-ratecontrol"

-- libmoon main, contains main()
require "main"

